package io.github.cursodsousa.icompras.servicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
