package io.github.cursodsousa.icompras.clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
